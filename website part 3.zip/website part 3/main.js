/* ============================================
   Cozziano Streetwear — main.js
   Handles: Lightbox Gallery, Enquiry Form Validation,
   Contact Form Validation
   ============================================ */

document.addEventListener("DOMContentLoaded", function () {
  initLightbox();
  initEnquiryForm();
  initContactForm();
});

/* ============================================
   LIGHTBOX GALLERY (products.html)
   ============================================ */
function initLightbox() {
  const triggers = document.querySelectorAll(".lightbox-trigger");
  const lightbox = document.getElementById("lightbox");
  if (!lightbox || triggers.length === 0) return;

  const lightboxImg = document.getElementById("lightboxImg");
  const lightboxCaption = document.getElementById("lightboxCaption");
  const closeBtn = document.getElementById("lightboxClose");

  triggers.forEach(function (img) {
    img.addEventListener("click", function () {
      openLightbox(img.src, img.dataset.caption || img.alt);
    });
    // keyboard accessibility
    img.setAttribute("tabindex", "0");
    img.setAttribute("role", "button");
    img.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        openLightbox(img.src, img.dataset.caption || img.alt);
      }
    });
  });

  function openLightbox(src, caption) {
    lightboxImg.src = src;
    lightboxImg.alt = caption;
    lightboxCaption.textContent = caption;
    lightbox.hidden = false;
    document.body.style.overflow = "hidden";
    closeBtn.focus();
  }

  function closeLightbox() {
    lightbox.hidden = true;
    lightboxImg.src = "";
    document.body.style.overflow = "";
  }

  closeBtn.addEventListener("click", closeLightbox);

  // Close when clicking the dark backdrop (outside the image/caption)
  lightbox.addEventListener("click", function (e) {
    if (e.target === lightbox) closeLightbox();
  });

  // Close on Escape key
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && !lightbox.hidden) closeLightbox();
  });
}

/* ============================================
   SHARED VALIDATION HELPERS
   ============================================ */
function showError(input, message) {
  const errorEl = document.getElementById(input.id + "-error");
  if (errorEl) errorEl.textContent = message;
  input.classList.add("invalid");
  input.classList.remove("valid");
}

function clearError(input) {
  const errorEl = document.getElementById(input.id + "-error");
  if (errorEl) errorEl.textContent = "";
  input.classList.remove("invalid");
  input.classList.add("valid");
}

function isValidEmail(value) {
  // simple, practical email pattern
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isValidSAPhone(value) {
  // South African format: starts with 0, 10 digits total
  return /^0[0-9]{9}$/.test(value.replace(/\s/g, ""));
}

/* ============================================
   ENQUIRY FORM (enquiry.html)
   ============================================ */
function initEnquiryForm() {
  const form = document.getElementById("enquiryForm");
  if (!form) return;

  const responseBox = document.getElementById("enquiryResponse");

  const productInfo = {
    "Tracksuit": { price: "R500", availability: "in stock, ships within 2-3 business days" },
    "Shorts": { price: "R250", availability: "in stock, ships within 2-3 business days" },
    "Skull Cap": { price: "R150", availability: "in stock, ships within 1-2 business days" },
    "Basketball Shorts": { price: "R600", availability: "limited stock, ships within 3-5 business days" }
  };

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("enq-name");
    const email = document.getElementById("enq-email");
    const product = document.getElementById("enq-product");
    const message = document.getElementById("enq-message");

    let isValid = true;

    if (name.value.trim().length < 2) {
      showError(name, "Please enter your full name (at least 2 characters).");
      isValid = false;
    } else {
      clearError(name);
    }

    if (!isValidEmail(email.value.trim())) {
      showError(email, "Please enter a valid email address.");
      isValid = false;
    } else {
      clearError(email);
    }

    if (!product.value) {
      showError(product, "Please select a product.");
      isValid = false;
    } else {
      clearError(product);
    }

    if (message.value.trim().length < 10) {
      showError(message, "Your message should be at least 10 characters.");
      isValid = false;
    } else {
      clearError(message);
    }

    if (!isValid) {
      responseBox.hidden = true;
      return;
    }

    // Build a response about cost/availability for the chosen product
    const info = productInfo[product.value];
    responseBox.hidden = false;
    responseBox.className = "form-response success";
    responseBox.innerHTML =
      "<strong>Thanks, " + escapeHTML(name.value.trim()) + "!</strong><br>" +
      "You asked about the <strong>" + escapeHTML(product.value) + "</strong>. " +
      "It's priced at <strong>" + info.price + "</strong> and is currently <strong>" + info.availability + "</strong>. " +
      "We've noted your message and will follow up at " + escapeHTML(email.value.trim()) + " if you need anything further.";

    form.reset();
    form.querySelectorAll(".valid").forEach(function (el) {
      el.classList.remove("valid");
    });
  });
}

/* ============================================
   CONTACT FORM (contact.html)
   ============================================ */
function initContactForm() {
  const form = document.getElementById("contactForm");
  if (!form) return;

  const responseBox = document.getElementById("contactResponse");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("con-name");
    const email = document.getElementById("con-email");
    const phone = document.getElementById("con-phone");
    const type = document.getElementById("con-type");
    const message = document.getElementById("con-message");

    let isValid = true;

    if (name.value.trim().length < 2) {
      showError(name, "Please enter your full name (at least 2 characters).");
      isValid = false;
    } else {
      clearError(name);
    }

    if (!isValidEmail(email.value.trim())) {
      showError(email, "Please enter a valid email address.");
      isValid = false;
    } else {
      clearError(email);
    }

    if (!isValidSAPhone(phone.value.trim())) {
      showError(phone, "Please enter a valid 10-digit number starting with 0 (e.g. 0812345678).");
      isValid = false;
    } else {
      clearError(phone);
    }

    if (!type.value) {
      showError(type, "Please select a message type.");
      isValid = false;
    } else {
      clearError(type);
    }

    if (message.value.trim().length < 10) {
      showError(message, "Your message should be at least 10 characters.");
      isValid = false;
    } else {
      clearError(message);
    }

    if (!isValid) {
      responseBox.hidden = true;
      return;
    }

    responseBox.hidden = false;
    responseBox.className = "form-response success";
    responseBox.innerHTML =
      "<strong>Message sent, thank you " + escapeHTML(name.value.trim()) + "!</strong><br>" +
      "Your <strong>" + escapeHTML(type.value) + "</strong> message has been received. " +
      "We'll get back to you at " + escapeHTML(email.value.trim()) + " or " + escapeHTML(phone.value.trim()) + " as soon as possible.";

    form.reset();
    form.querySelectorAll(".valid").forEach(function (el) {
      el.classList.remove("valid");
    });
  });
}

/* ============================================
   UTILITY: basic HTML escaping for inserted text
   ============================================ */
function escapeHTML(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
